# Ace Guardian AI Pro

Enterprise-grade AI security solutions powered by the Lalilama AI system.

## 🌐 Live Website

**URL:** https://aceguardian.org

## 🚀 Tech Stack

- React + TypeScript
- Vite
- Tailwind CSS
- shadcn/ui components

## 📁 Project Structure

```
├── src/
│   ├── sections/          # Page sections
│   │   ├── Navigation.tsx
│   │   ├── Hero.tsx
│   │   ├── Mission.tsx
│   │   ├── Technology.tsx
│   │   ├── History.tsx
│   │   ├── Team.tsx
│   │   ├── FAQ.tsx
│   │   ├── CTA.tsx
│   │   └── Footer.tsx
│   ├── components/ui/     # shadcn/ui components
│   ├── hooks/             # Custom hooks
│   ├── App.tsx
│   └── index.css
├── public/                # Static assets
│   ├── hero-bg.jpg
│   └── team-bg.jpg
├── dist/                  # Build output
└── index.html
```

## 🛠️ Development

```bash
# Install dependencies
npm install

# Start development server
npm run dev

# Build for production
npm run build
```

## 🚀 Deployment to Vercel

### Option 1: GitHub Integration (Recommended)

1. Push this repository to GitHub
2. Go to [vercel.com](https://vercel.com)
3. Click **Add New Project**
4. Import your GitHub repository
5. Vercel will auto-detect Vite settings
6. Click **Deploy**

### Option 2: Vercel CLI

```bash
# Install Vercel CLI
npm i -g vercel

# Login and deploy
vercel login
vercel
```

## 🌐 Custom Domain Setup

1. In Vercel dashboard, go to your project
2. Click **Settings** → **Domains**
3. Add `aceguardian.org`
4. Follow DNS configuration instructions:
   - **Option A:** Use Vercel Nameservers
   - **Option B:** Add A/CNAME records

### DNS Configuration (Option B)

| Type | Name | Value |
|------|------|-------|
| A | @ | 76.76.21.21 |
| CNAME | www | cname.vercel-dns.com |

## 📝 Making Changes

1. Edit files in `src/sections/`
2. Test locally: `npm run dev`
3. Commit and push to GitHub
4. Vercel auto-deploys on every push

## 📧 Contact

**Paul Langlois** - Founder & Chief Architect  
📧 paul@aceguardianaipro.com  
📞 1-250-255-7321

---

© 2025 Ace Guardian AI Pro Inc. All rights reserved.
