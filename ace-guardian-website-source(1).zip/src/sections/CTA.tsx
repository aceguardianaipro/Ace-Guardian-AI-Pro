import { Mail, Phone, MapPin, ArrowRight } from 'lucide-react';
import { useState } from 'react';

const CTA = () => {
  const [copiedField, setCopiedField] = useState<string | null>(null);

  const contactInfo = [
    {
      icon: Mail,
      label: 'Email',
      value: 'paul@aceguardianaipro.com',
      href: 'mailto:paul@aceguardianaipro.com',
    },
    {
      icon: Phone,
      label: 'Phone',
      value: '1-250-255-7321',
      href: 'tel:+12502557321',
    },
    {
      icon: MapPin,
      label: 'Address',
      value: '839 ROLPH ST V2J 4X2 QUESNEL B.C.',
      href: '#',
    },
  ];

  const copyToClipboard = (text: string, field: string) => {
    navigator.clipboard.writeText(text);
    setCopiedField(field);
    setTimeout(() => setCopiedField(null), 2000);
  };

  return (
    <section
      id="contact"
      className="relative py-24 md:py-32 overflow-hidden"
    >
      {/* Animated Gradient Background */}
      <div className="absolute inset-0 animated-gradient" />
      
      {/* Gradient Orbs */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-1/4 w-[500px] h-[500px] rounded-full bg-[#7f5cff]/20 blur-[150px] -translate-y-1/2 float-animation" />
        <div className="absolute top-1/2 right-1/4 w-[400px] h-[400px] rounded-full bg-[#00e1ff]/15 blur-[120px] -translate-y-1/2 float-animation" style={{ animationDelay: '-3s' }} />
      </div>

      {/* Grid Pattern */}
      <div className="absolute inset-0 grid-pattern opacity-30" />

      <div className="relative z-10 max-w-[1440px] mx-auto px-[5%]">
        <div className="max-w-4xl mx-auto">
          {/* Main CTA Card */}
          <div className="reveal">
            <div className="relative p-8 md:p-16 rounded-3xl bg-white/[0.03] border border-white/10 backdrop-blur-sm overflow-hidden">
              {/* Background Glow */}
              <div className="absolute inset-0 bg-gradient-to-br from-[#7f5cff]/10 via-transparent to-[#00e1ff]/10" />

              <div className="relative z-10 text-center">
                {/* Badge */}
                <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/5 border border-white/10 mb-8">
                  <span className="w-2 h-2 rounded-full bg-[#00ff88] animate-pulse" />
                  <span className="text-sm text-white/70">Ready to deploy</span>
                </div>

                {/* Headline */}
                <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-white mb-6">
                  Ready for{' '}
                  <span className="gradient-text">Uncompromising Security?</span>
                </h2>

                {/* Description */}
                <p className="text-lg text-white/60 mb-10 max-w-2xl mx-auto">
                  Join the enterprises and individuals who trust Ace Guardian AI Pro 
                  for their most critical security needs. Get in touch today.
                </p>

                {/* CTA Button */}
                <a
                  href="mailto:paul@aceguardianaipro.com"
                  className="inline-flex items-center gap-3 btn-gradient px-8 py-4 rounded-full text-base font-medium text-white group"
                >
                  Get in Touch
                  <ArrowRight className="w-5 h-5 group-hover:translate-x-1 transition-transform duration-300" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Info Cards */}
          <div className="mt-12 grid grid-cols-1 md:grid-cols-3 gap-6 stagger-children">
            {contactInfo.map((info, index) => (
              <a
                key={index}
                href={info.href}
                onClick={(e) => {
                  if (info.label === 'Address') {
                    e.preventDefault();
                    copyToClipboard(info.value, info.label);
                  }
                }}
                className="group p-6 rounded-2xl bg-white/[0.02] border border-white/10 hover:border-[#7f5cff]/30 transition-all duration-300 text-center"
              >
                {/* Icon */}
                <div className="w-12 h-12 rounded-xl bg-[#7f5cff]/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <info.icon className="w-6 h-6 text-[#7f5cff]" />
                </div>

                {/* Label */}
                <div className="text-sm text-white/50 mb-2">{info.label}</div>

                {/* Value */}
                <div className="text-white font-medium relative">
                  {info.value}
                  {copiedField === info.label && (
                    <span className="absolute -top-8 left-1/2 -translate-x-1/2 px-2 py-1 rounded bg-[#00ff88] text-black text-xs">
                      Copied!
                    </span>
                  )}
                </div>
              </a>
            ))}
          </div>

          {/* Status Indicators */}
          <div className="mt-12 flex flex-wrap justify-center gap-4 reveal">
            {[
              { label: 'Phase 3', sublabel: 'Production' },
              { label: 'Code Complete', sublabel: 'Verified' },
              { label: 'App Stores', sublabel: 'Pending' },
            ].map((status, index) => (
              <div
                key={index}
                className="flex items-center gap-3 px-5 py-3 rounded-full bg-white/5 border border-white/10"
              >
                <span className="w-2 h-2 rounded-full bg-[#00e1ff]" />
                <div>
                  <span className="text-sm font-medium text-white">{status.label}</span>
                  <span className="text-xs text-white/50 ml-2">{status.sublabel}</span>
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  );
};

export default CTA;
