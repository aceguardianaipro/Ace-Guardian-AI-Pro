import { useState } from 'react';
import { ChevronDown, Shield, RefreshCw, Lock, Download, Building } from 'lucide-react';

const faqs = [
  {
    question: 'What makes Ace Guardian AI Pro different from traditional security applications?',
    answer:
      'The difference is the Lalilama AI Core. Most security apps are reactive—they wait for a server to tell them what to do, creating dangerous latency. Ace Guardian is built on a "Rapid Response" architecture that processes threats locally on the device (Edge Computing). This means decisions happen in milliseconds, not seconds.',
    icon: Shield,
    color: '#7f5cff',
  },
  {
    question: 'What is the "Self-Healing" capability?',
    answer:
      'In high-risk environments, system failure is not an option. Our Self-Healing architecture continuously monitors the app\'s own operational code. If it detects a potential crash, instability, or memory leak, it automatically reroutes processes and repairs the issue without interrupting the user\'s protection.',
    icon: RefreshCw,
    color: '#00e1ff',
  },
  {
    question: 'Is my data sent to a cloud server?',
    answer:
      'We prioritize Privacy by Design. Because the Lalilama core is lightweight and efficient, the majority of threat analysis happens directly on your device. This minimizes the amount of data leaving your secure environment, reducing your digital footprint and increasing privacy.',
    icon: Lock,
    color: '#ff2d53',
  },
  {
    question: 'When will the application be available for download?',
    answer:
      'We are currently in Phase 3: Production Deployment. The application is "Code Complete" and is currently undergoing final verification processes for both the Google Play Store (Android) and Apple App Store (iOS). We anticipate a public release shortly.',
    icon: Download,
    color: '#00ff88',
  },
  {
    question: 'Is this solution for enterprise or personal use?',
    answer:
      'Ace Guardian AI Pro was engineered with Enterprise-Grade standards—meaning it is robust enough for industrial and corporate security. However, this same level of "unstoppable" protection is available to individual users who demand professional-level safety for themselves and their families.',
    icon: Building,
    color: '#ffb800',
  },
];

const FAQ = () => {
  const [openIndex, setOpenIndex] = useState<number | null>(null);

  const toggleFAQ = (index: number) => {
    setOpenIndex(openIndex === index ? null : index);
  };

  return (
    <section id="faq" className="relative py-24 md:py-32 bg-[#0d0d0d]">
      {/* Background */}
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="relative z-10 max-w-[1440px] mx-auto px-[5%]">
        {/* Section Header */}
        <div className="text-center mb-16 reveal">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/60 mb-6">
            FAQ
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-white mb-4">
            Frequently Asked
            <span className="gradient-text"> Questions</span>
          </h2>
          <p className="max-w-2xl mx-auto text-white/60 text-lg">
            Everything you need to know about Ace Guardian AI Pro
          </p>
        </div>

        {/* FAQ List */}
        <div className="max-w-3xl mx-auto space-y-4 stagger-children">
          {faqs.map((faq, index) => (
            <div
              key={index}
              className="rounded-2xl bg-white/[0.02] border border-white/10 overflow-hidden transition-all duration-300 hover:border-white/20"
            >
              {/* Question Button */}
              <button
                onClick={() => toggleFAQ(index)}
                className="w-full p-6 flex items-center gap-4 text-left group"
              >
                {/* Icon */}
                <div
                  className="flex-shrink-0 w-10 h-10 rounded-lg flex items-center justify-center transition-transform duration-300 group-hover:scale-110"
                  style={{ backgroundColor: `${faq.color}15` }}
                >
                  <faq.icon className="w-5 h-5" style={{ color: faq.color }} />
                </div>

                {/* Question Text */}
                <span className="flex-1 text-base md:text-lg font-medium text-white group-hover:text-white/90 transition-colors">
                  {faq.question}
                </span>

                {/* Toggle Icon */}
                <ChevronDown
                  className={`w-5 h-5 text-white/40 transition-transform duration-300 ${
                    openIndex === index ? 'rotate-180' : ''
                  }`}
                />
              </button>

              {/* Answer */}
              <div
                className={`overflow-hidden transition-all duration-400 ${
                  openIndex === index ? 'max-h-96 opacity-100' : 'max-h-0 opacity-0'
                }`}
                style={{
                  transitionTimingFunction: 'cubic-bezier(0.165, 0.840, 0.440, 1)',
                }}
              >
                <div className="px-6 pb-6 pl-20">
                  <p className="text-white/60 leading-relaxed">{faq.answer}</p>
                </div>
              </div>
            </div>
          ))}
        </div>

        {/* Still Have Questions */}
        <div className="mt-16 text-center reveal">
          <p className="text-white/60 mb-4">Still have questions?</p>
          <a
            href="#contact"
            onClick={(e) => {
              e.preventDefault();
              document.querySelector('#contact')?.scrollIntoView({ behavior: 'smooth' });
            }}
            className="inline-flex items-center gap-2 text-[#7f5cff] hover:text-[#00e1ff] transition-colors duration-300"
          >
            Get in touch with us
            <svg
              className="w-4 h-4"
              fill="none"
              stroke="currentColor"
              viewBox="0 0 24 24"
            >
              <path
                strokeLinecap="round"
                strokeLinejoin="round"
                strokeWidth={2}
                d="M17 8l4 4m0 0l-4 4m4-4H3"
              />
            </svg>
          </a>
        </div>
      </div>
    </section>
  );
};

export default FAQ;
