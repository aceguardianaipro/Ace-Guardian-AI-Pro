import { Shield, Linkedin, Twitter, Github, Mail } from 'lucide-react';

const Footer = () => {
  const currentYear = new Date().getFullYear();

  const quickLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Mission', href: '#mission' },
    { label: 'Technology', href: '#technology' },
    { label: 'History', href: '#history' },
    { label: 'Team', href: '#team' },
    { label: 'FAQ', href: '#faq' },
  ];

  const socialLinks = [
    { icon: Linkedin, href: 'https://linkedin.com', label: 'LinkedIn' },
    { icon: Twitter, href: 'https://twitter.com', label: 'Twitter' },
    { icon: Github, href: 'https://github.com', label: 'GitHub' },
    { icon: Mail, href: 'mailto:paul@aceguardianaipro.com', label: 'Email' },
  ];

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <footer className="relative bg-[#090909] border-t border-white/5">
      {/* Main Footer */}
      <div className="max-w-[1440px] mx-auto px-[5%] py-16">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-12">
          {/* Brand Column */}
          <div className="lg:col-span-2">
            {/* Logo */}
            <a
              href="#home"
              onClick={(e) => {
                e.preventDefault();
                scrollToSection('#home');
              }}
              className="flex items-center gap-3 mb-6 group"
            >
              <div className="w-10 h-10 rounded-lg bg-gradient-to-br from-[#7f5cff] to-[#00e1ff] flex items-center justify-center group-hover:scale-110 transition-transform duration-300">
                <Shield className="w-5 h-5 text-white" />
              </div>
              <span className="font-semibold text-lg tracking-wide">
                ACE GUARDIAN AI PRO
              </span>
            </a>

            {/* Tagline */}
            <p className="text-white/60 mb-6 max-w-md">
              The Future of AI Deployment is Here. Enterprise-grade security solutions 
              powered by the Lalilama AI system.
            </p>

            {/* Social Links */}
            <div className="flex gap-3">
              {socialLinks.map((social, index) => (
                <a
                  key={index}
                  href={social.href}
                  target="_blank"
                  rel="noopener noreferrer"
                  aria-label={social.label}
                  className="w-10 h-10 rounded-lg bg-white/5 border border-white/10 flex items-center justify-center text-white/60 hover:text-white hover:border-[#7f5cff]/50 hover:bg-[#7f5cff]/10 transition-all duration-300"
                >
                  <social.icon className="w-5 h-5" />
                </a>
              ))}
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h4 className="text-white font-semibold mb-6">Quick Links</h4>
            <ul className="space-y-3">
              {quickLinks.map((link, index) => (
                <li key={index}>
                  <a
                    href={link.href}
                    onClick={(e) => {
                      e.preventDefault();
                      scrollToSection(link.href);
                    }}
                    className="text-white/60 hover:text-white transition-colors duration-300"
                  >
                    {link.label}
                  </a>
                </li>
              ))}
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h4 className="text-white font-semibold mb-6">Contact</h4>
            <ul className="space-y-4">
              <li>
                <a
                  href="mailto:paul@aceguardianaipro.com"
                  className="text-white/60 hover:text-white transition-colors duration-300"
                >
                  paul@aceguardianaipro.com
                </a>
              </li>
              <li>
                <a
                  href="tel:+12502557321"
                  className="text-white/60 hover:text-white transition-colors duration-300"
                >
                  1-250-255-7321
                </a>
              </li>
              <li className="text-white/60">
                839 ROLPH ST<br />
                V2J 4X2 QUESNEL B.C.
              </li>
            </ul>
          </div>
        </div>
      </div>

      {/* Bottom Bar */}
      <div className="border-t border-white/5">
        <div className="max-w-[1440px] mx-auto px-[5%] py-6">
          <div className="flex flex-col md:flex-row items-center justify-between gap-4">
            {/* Copyright */}
            <p className="text-sm text-white/40 text-center md:text-left">
              © {currentYear} Ace Guardian AI Pro Inc. All rights reserved.
            </p>

            {/* Legal Links */}
            <div className="flex gap-6">
              <a
                href="#"
                className="text-sm text-white/40 hover:text-white/60 transition-colors duration-300"
              >
                Privacy Policy
              </a>
              <a
                href="#"
                className="text-sm text-white/40 hover:text-white/60 transition-colors duration-300"
              >
                Terms of Service
              </a>
            </div>
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
