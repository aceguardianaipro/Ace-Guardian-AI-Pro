import { useEffect, useRef } from 'react';
import { ChevronDown, Shield, Zap, RefreshCw } from 'lucide-react';

const Hero = () => {
  const heroRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleMouseMove = (e: MouseEvent) => {
      if (!heroRef.current) return;
      const { clientX, clientY } = e;
      const { innerWidth, innerHeight } = window;
      
      const x = (clientX / innerWidth - 0.5) * 10;
      const y = (clientY / innerHeight - 0.5) * 10;
      
      const bgImage = heroRef.current.querySelector('.hero-bg-image') as HTMLElement;
      if (bgImage) {
        bgImage.style.transform = `translate(${x}px, ${y}px) scale(1.05)`;
      }
    };

    window.addEventListener('mousemove', handleMouseMove, { passive: true });
    return () => window.removeEventListener('mousemove', handleMouseMove);
  }, []);

  const scrollToSection = (href: string) => {
    const element = document.querySelector(href);
    if (element) {
      element.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <section
      id="home"
      ref={heroRef}
      className="relative min-h-screen flex items-center justify-center overflow-hidden"
    >
      {/* Full-bleed Background Image */}
      <div className="absolute inset-0 overflow-hidden">
        <div 
          className="hero-bg-image absolute inset-[-20px] transition-transform duration-300 ease-out"
          style={{ 
            backgroundImage: 'url(/hero-bg.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        {/* Dark overlay for text readability */}
        <div className="absolute inset-0 bg-gradient-to-b from-[#090909]/70 via-[#090909]/50 to-[#090909]" />
      </div>

      {/* Grid Pattern Overlay */}
      <div className="absolute inset-0 grid-pattern opacity-30" />

      {/* Content */}
      <div className="relative z-10 max-w-[1440px] mx-auto px-[5%] py-32 text-center">
        {/* Badge */}
        <div 
          className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20 mb-8"
          style={{
            animation: 'fadeInUp 0.8s cubic-bezier(0.165, 0.840, 0.440, 1) forwards',
            opacity: 0,
          }}
        >
          <span className="w-2 h-2 rounded-full bg-[#00ff88] animate-pulse" />
          <span className="text-sm text-white/90">Now in Production Deployment</span>
        </div>

        {/* Main Headline */}
        <h1 
          className="text-4xl sm:text-5xl md:text-6xl lg:text-7xl font-semibold leading-tight mb-6"
          style={{
            animation: 'fadeInUp 0.8s 0.2s cubic-bezier(0.165, 0.840, 0.440, 1) forwards',
            opacity: 0,
          }}
        >
          <span className="block text-white/90">The Future of</span>
          <span className="block gradient-text mt-2">AI Deployment is Here</span>
        </h1>

        {/* Subheadline */}
        <p 
          className="text-xl sm:text-2xl md:text-3xl font-medium text-white/80 mb-8"
          style={{
            animation: 'fadeInUp 0.8s 0.4s cubic-bezier(0.165, 0.840, 0.440, 1) forwards',
            opacity: 0,
          }}
        >
          Ace Guardian AI Pro
        </p>

        {/* Description */}
        <p 
          className="max-w-2xl mx-auto text-base sm:text-lg text-white/70 mb-12 leading-relaxed"
          style={{
            animation: 'fadeInUp 0.8s 0.6s cubic-bezier(0.165, 0.840, 0.440, 1) forwards',
            opacity: 0,
          }}
        >
          Enterprise-grade AI solutions powered by the <span className="text-[#7f5cff] font-medium">Lalilama AI system</span>. 
          Self-healing architecture. Rapid response capabilities. Uncompromising security.
        </p>

        {/* Feature Pills */}
        <div 
          className="flex flex-wrap justify-center gap-4 mb-12"
          style={{
            animation: 'fadeInUp 0.8s 0.7s cubic-bezier(0.165, 0.840, 0.440, 1) forwards',
            opacity: 0,
          }}
        >
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
            <RefreshCw className="w-4 h-4 text-[#7f5cff]" />
            <span className="text-sm text-white/80">Self-Healing</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
            <Zap className="w-4 h-4 text-[#00e1ff]" />
            <span className="text-sm text-white/80">Rapid Response</span>
          </div>
          <div className="flex items-center gap-2 px-4 py-2 rounded-full bg-white/10 backdrop-blur-sm border border-white/20">
            <Shield className="w-4 h-4 text-[#ff2d53]" />
            <span className="text-sm text-white/80">Enterprise Security</span>
          </div>
        </div>

        {/* CTA Buttons */}
        <div 
          className="flex flex-col sm:flex-row items-center justify-center gap-4"
          style={{
            animation: 'fadeInUp 0.8s 0.8s cubic-bezier(0.165, 0.840, 0.440, 1) forwards',
            opacity: 0,
          }}
        >
          <button
            onClick={() => scrollToSection('#technology')}
            className="btn-gradient px-8 py-4 rounded-full text-base font-medium text-white flex items-center gap-2"
          >
            Explore Our Technology
          </button>
          <button
            onClick={() => scrollToSection('#contact')}
            className="px-8 py-4 rounded-full text-base font-medium text-white border border-white/30 hover:border-white/50 hover:bg-white/10 backdrop-blur-sm transition-all duration-300"
          >
            Contact Us
          </button>
        </div>
      </div>

      {/* Scroll Indicator */}
      <div 
        className="absolute bottom-8 left-1/2 -translate-x-1/2 flex flex-col items-center gap-2"
        style={{
          animation: 'fadeIn 1s 1.2s forwards',
          opacity: 0,
        }}
      >
        <span className="text-xs text-white/50">Scroll to explore</span>
        <ChevronDown className="w-5 h-5 text-white/50 pulse-animation" />
      </div>

      {/* Bottom Gradient Fade */}
      <div className="absolute bottom-0 left-0 right-0 h-32 bg-gradient-to-t from-[#090909] to-transparent" />

      <style>{`
        @keyframes fadeInUp {
          from {
            opacity: 0;
            transform: translateY(30px);
          }
          to {
            opacity: 1;
            transform: translateY(0);
          }
        }
        @keyframes fadeIn {
          from {
            opacity: 0;
          }
          to {
            opacity: 1;
          }
        }
      `}</style>
    </section>
  );
};

export default Hero;
