import { useEffect, useRef, useState } from 'react';
import { TreePine, Truck, Heart, Activity, Cpu } from 'lucide-react';

const timelineEvents = [
  {
    date: 'Early Years',
    title: 'Foundation in High-Consequence Environments',
    description:
      'Paul Langlois learned that survival depends on preparedness—from family towing business to navigating untouched wilderness for mapping operations.',
    icon: Truck,
    color: '#7f5cff',
  },
  {
    date: 'Career Peak',
    title: 'Pushing Physical & Mental Limits',
    description:
      'Working as an arborist climbing 140ft trees near 500kv power lines and operating heavy industrial cranes in the oilfields.',
    icon: TreePine,
    color: '#00e1ff',
  },
  {
    date: 'The Catalyst',
    title: 'A Legacy of Protection',
    description:
      'Following the passing of his grandmother—the original dispatcher who "protected everyone"—Paul sought to build a system that could carry that legacy into the digital age.',
    icon: Heart,
    color: '#ff2d53',
  },
  {
    date: 'The Injury',
    title: 'The Ultimate Lesson in Resilience',
    description:
      'A catastrophic work injury crushing his left side required a year of intense rebuilding. True strength comes from the ability to heal and adapt.',
    icon: Activity,
    color: '#ffb800',
  },
  {
    date: 'Today',
    title: 'The Lalilama Architecture',
    description:
      'Rejecting bloated, slow code of traditional tech, Paul engineered a system designed for Rapid Response and Self-Healing—an AI that repairs itself in real-time.',
    icon: Cpu,
    color: '#00ff88',
  },
];

const History = () => {
  const [lineHeight, setLineHeight] = useState(0);
  const sectionRef = useRef<HTMLDivElement>(null);
  const timelineRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const handleScroll = () => {
      if (!sectionRef.current || !timelineRef.current) return;

      const section = sectionRef.current;
      const rect = section.getBoundingClientRect();
      const sectionHeight = section.offsetHeight;
      const viewportHeight = window.innerHeight;

      // Calculate progress based on section visibility
      const scrollProgress = Math.max(
        0,
        Math.min(1, (viewportHeight - rect.top) / (sectionHeight + viewportHeight * 0.5))
      );

      setLineHeight(scrollProgress * 100);
    };

    window.addEventListener('scroll', handleScroll, { passive: true });
    handleScroll(); // Initial call

    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  return (
    <section
      id="history"
      ref={sectionRef}
      className="relative py-24 md:py-32 bg-[#0d0d0d] overflow-hidden"
    >
      {/* Background */}
      <div className="absolute inset-0 grid-pattern opacity-20" />

      <div className="relative z-10 max-w-[1440px] mx-auto px-[5%]">
        {/* Section Header */}
        <div className="text-center mb-20 reveal">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/60 mb-6">
            Our Journey
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-white mb-4">
            Forged in the Field,
            <span className="gradient-text"> Not the Lab</span>
          </h2>
          <p className="max-w-2xl mx-auto text-white/60 text-lg">
            The Journey of Ace Guardian AI Pro
          </p>
        </div>

        {/* Timeline */}
        <div ref={timelineRef} className="relative max-w-4xl mx-auto">
          {/* Timeline Line */}
          <div className="absolute left-4 md:left-1/2 top-0 bottom-0 w-px bg-white/10 md:-translate-x-1/2">
            <div
              className="absolute top-0 left-0 w-full bg-gradient-to-b from-[#7f5cff] via-[#00e1ff] to-[#00ff88] transition-all duration-300"
              style={{ height: `${lineHeight}%` }}
            />
          </div>

          {/* Timeline Events */}
          <div className="space-y-16 md:space-y-24">
            {timelineEvents.map((event, index) => (
              <div
                key={index}
                className={`relative flex items-start gap-8 md:gap-0 reveal ${
                  index % 2 === 0 ? 'md:flex-row' : 'md:flex-row-reverse'
                }`}
              >
                {/* Content */}
                <div
                  className={`flex-1 ml-12 md:ml-0 ${
                    index % 2 === 0 ? 'md:pr-16 md:text-right' : 'md:pl-16 md:text-left'
                  }`}
                >
                  {/* Date Badge */}
                  <div
                    className={`inline-flex items-center gap-2 px-3 py-1 rounded-full text-sm font-medium mb-4 ${
                      index % 2 === 0 ? 'md:ml-auto' : ''
                    }`}
                    style={{
                      backgroundColor: `${event.color}15`,
                      color: event.color,
                    }}
                  >
                    {event.date}
                  </div>

                  {/* Title */}
                  <h3 className="text-xl md:text-2xl font-semibold text-white mb-3">
                    {event.title}
                  </h3>

                  {/* Description */}
                  <p className="text-white/60 leading-relaxed max-w-md">
                    {event.description}
                  </p>
                </div>

                {/* Center Icon */}
                <div className="absolute left-4 md:left-1/2 md:-translate-x-1/2 flex items-center justify-center">
                  <div
                    className="w-10 h-10 rounded-full border-2 flex items-center justify-center bg-[#0d0d0d] z-10 transition-transform duration-300 hover:scale-125"
                    style={{ borderColor: event.color }}
                  >
                    <event.icon className="w-4 h-4" style={{ color: event.color }} />
                  </div>
                </div>

                {/* Empty Space for Alternating Layout */}
                <div className="hidden md:block flex-1" />
              </div>
            ))}
          </div>
        </div>

        {/* Quote */}
        <div className="mt-24 text-center reveal">
          <blockquote className="max-w-3xl mx-auto">
            <p className="text-2xl md:text-3xl font-light text-white/80 italic mb-6">
              "True strength comes from the ability to heal and adapt."
            </p>
            <footer className="text-white/50">
              — Paul Langlois, Founder & Chief Architect
            </footer>
          </blockquote>
        </div>
      </div>
    </section>
  );
};

export default History;
