import { Rocket, Shield, Zap } from 'lucide-react';

const missions = [
  {
    icon: Rocket,
    title: 'Accelerate Enterprise Success',
    description:
      'To accelerate professional and enterprise success by providing secure, reliable, and cutting-edge AI systems, powered by the core Lalilama AI engine.',
    color: '#7f5cff',
  },
  {
    icon: Shield,
    title: 'Seamless AI Integration',
    description:
      'Our mission is to seamlessly transition complex AI capabilities, driven by the Lalilama AI system, into robust, professionally deployed, and highly secure applications for critical enterprise use.',
    color: '#00e1ff',
  },
  {
    icon: Zap,
    title: 'Transform Security & Efficiency',
    description:
      'Ace Guardian AI Pro exists to transform security and operational efficiency for businesses through specialized, scalable AI solutions leveraging the unique capabilities of the Lalilama AI system.',
    color: '#ff2d53',
  },
];

const Mission = () => {
  return (
    <section id="mission" className="relative py-24 md:py-32 bg-[#0d0d0d]">
      {/* Background Pattern */}
      <div className="absolute inset-0 grid-pattern opacity-30" />

      <div className="relative z-10 max-w-[1440px] mx-auto px-[5%]">
        {/* Section Header */}
        <div className="text-center mb-16 reveal">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/60 mb-6">
            Our Mission
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-white mb-4">
            Building the Future of
            <span className="gradient-text"> AI Security</span>
          </h2>
          <p className="max-w-2xl mx-auto text-white/60 text-lg">
            Three pillars guide everything we do at Ace Guardian AI Pro
          </p>
        </div>

        {/* Mission Cards */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 lg:gap-8 stagger-children">
          {missions.map((mission, index) => (
            <div
              key={index}
              className="group relative p-8 rounded-2xl bg-white/[0.02] border border-white/10 card-hover overflow-hidden"
            >
              {/* Glow Effect on Hover */}
              <div
                className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500"
                style={{
                  background: `radial-gradient(circle at 50% 0%, ${mission.color}15 0%, transparent 70%)`,
                }}
              />

              {/* Content */}
              <div className="relative z-10">
                {/* Icon */}
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110"
                  style={{ backgroundColor: `${mission.color}15` }}
                >
                  <mission.icon
                    className="w-7 h-7"
                    style={{ color: mission.color }}
                  />
                </div>

                {/* Title */}
                <h3 className="text-xl font-semibold text-white mb-4">
                  {mission.title}
                </h3>

                {/* Description */}
                <p className="text-white/60 leading-relaxed">
                  {mission.description}
                </p>

                {/* Accent Line */}
                <div
                  className="absolute bottom-0 left-0 right-0 h-1 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"
                  style={{
                    background: `linear-gradient(90deg, ${mission.color} 0%, transparent 100%)`,
                  }}
                />
              </div>
            </div>
          ))}
        </div>

        {/* Stats Row */}
        <div className="mt-20 grid grid-cols-2 md:grid-cols-4 gap-8 reveal">
          {[
            { value: '99.99%', label: 'Uptime Guarantee' },
            { value: '<10ms', label: 'Response Time' },
            { value: '24/7', label: 'AI Operations' },
            { value: '100%', label: 'Edge Processing' },
          ].map((stat, index) => (
            <div key={index} className="text-center">
              <div className="text-3xl md:text-4xl font-bold gradient-text mb-2">
                {stat.value}
              </div>
              <div className="text-sm text-white/50">{stat.label}</div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Mission;
