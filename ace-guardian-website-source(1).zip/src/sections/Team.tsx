import { Users, Bot, Network } from 'lucide-react';

const Team = () => {
  return (
    <section id="team" className="relative py-24 md:py-32 overflow-hidden">
      {/* Background Image */}
      <div className="absolute inset-0">
        <div 
          className="absolute inset-0"
          style={{ 
            backgroundImage: 'url(/team-bg.jpg)',
            backgroundSize: 'cover',
            backgroundPosition: 'center',
          }}
        />
        {/* Dark overlay */}
        <div className="absolute inset-0 bg-[#090909]/85" />
      </div>

      {/* Additional gradient overlays */}
      <div className="absolute inset-0">
        <div className="absolute top-0 left-1/4 w-[600px] h-[600px] rounded-full bg-[#7f5cff]/5 blur-[150px]" />
        <div className="absolute bottom-0 right-1/4 w-[500px] h-[500px] rounded-full bg-[#00e1ff]/5 blur-[120px]" />
      </div>

      <div className="relative z-10 max-w-[1440px] mx-auto px-[5%]">
        {/* Section Header */}
        <div className="text-center mb-20 reveal">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/60 mb-6">
            Our Team
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-white mb-4">
            The Architects of
            <span className="gradient-text"> Protection</span>
          </h2>
        </div>

        {/* Founder Card - Large */}
        <div className="mb-16 reveal">
          <div className="relative max-w-4xl mx-auto">
            <div className="group relative p-8 md:p-12 rounded-3xl bg-white/[0.05] backdrop-blur-sm border border-white/10 overflow-hidden card-hover">
              {/* Background Glow */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500 bg-gradient-to-br from-[#7f5cff]/10 via-transparent to-[#00e1ff]/10" />

              <div className="relative z-10 flex flex-col md:flex-row items-center gap-8 md:gap-12">
                {/* Avatar */}
                <div className="flex-shrink-0">
                  <div className="w-32 h-32 md:w-40 md:h-40 rounded-full bg-gradient-to-br from-[#7f5cff] to-[#00e1ff] p-1">
                    <div className="w-full h-full rounded-full bg-[#0d0d0d] flex items-center justify-center">
                      <span className="text-4xl md:text-5xl font-bold gradient-text">
                        PL
                      </span>
                    </div>
                  </div>
                </div>

                {/* Content */}
                <div className="text-center md:text-left flex-1">
                  <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-[#7f5cff]/10 text-[#7f5cff] text-sm mb-4">
                    Founder & Chief Architect
                  </div>
                  <h3 className="text-2xl md:text-3xl font-semibold text-white mb-4">
                    Paul Langlois
                  </h3>
                  <p className="text-white/60 leading-relaxed mb-6">
                    With a background defined by high-consequence decision-making—from 
                    industrial heavy recovery to critical infrastructure management—Paul 
                    directs the strategic vision of the platform. He is not just the developer; 
                    he is the <span className="text-[#7f5cff] font-medium">Architect</span>, 
                    ensuring that every line of code serves the mission of protection and resilience.
                  </p>

                  {/* Stats */}
                  <div className="flex flex-wrap justify-center md:justify-start gap-6">
                    {[
                      { label: 'Years Experience', value: '20+' },
                      { label: 'Industries', value: '5+' },
                      { label: 'Core Mission', value: 'Protection' },
                    ].map((stat, index) => (
                      <div key={index} className="text-center">
                        <div className="text-xl font-bold text-white">{stat.value}</div>
                        <div className="text-xs text-white/50">{stat.label}</div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Advisory & AI Division Grid */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          {/* Advisory Network */}
          <div className="reveal">
            <div className="group relative h-full p-8 rounded-2xl bg-white/[0.05] backdrop-blur-sm border border-white/10 card-hover overflow-hidden">
              {/* Background */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute top-0 right-0 w-40 h-40 bg-[#00e1ff]/10 rounded-full blur-[60px]" />
              </div>

              <div className="relative z-10">
                {/* Icon */}
                <div className="w-14 h-14 rounded-xl bg-[#00e1ff]/10 flex items-center justify-center mb-6">
                  <Network className="w-7 h-7 text-[#00e1ff]" />
                </div>

                {/* Title */}
                <h3 className="text-xl font-semibold text-white mb-4 flex items-center gap-3">
                  Advisory Network
                  <Users className="w-5 h-5 text-white/40" />
                </h3>

                {/* Description */}
                <p className="text-white/60 leading-relaxed mb-6">
                  The company is guided by a private council of industry veterans in security, 
                  heavy industry, and systems engineering. This network ensures that Ace Guardian 
                  AI Pro remains grounded in the practical realities of the field while pushing 
                  the boundaries of what is technically possible.
                </p>

                {/* Tags */}
                <div className="flex flex-wrap gap-2">
                  {['Security Experts', 'Industry Veterans', 'Systems Engineers'].map(
                    (tag, index) => (
                      <span
                        key={index}
                        className="px-3 py-1 rounded-full text-xs bg-white/5 text-white/60 border border-white/10"
                      >
                        {tag}
                      </span>
                    )
                  )}
                </div>
              </div>
            </div>
          </div>

          {/* AI Operations Division */}
          <div className="reveal">
            <div className="group relative h-full p-8 rounded-2xl bg-white/[0.05] backdrop-blur-sm border border-white/10 card-hover overflow-hidden">
              {/* Background */}
              <div className="absolute inset-0 opacity-0 group-hover:opacity-100 transition-opacity duration-500">
                <div className="absolute bottom-0 left-0 w-40 h-40 bg-[#ff2d53]/10 rounded-full blur-[60px]" />
              </div>

              <div className="relative z-10">
                {/* Icon */}
                <div className="w-14 h-14 rounded-xl bg-[#ff2d53]/10 flex items-center justify-center mb-6">
                  <Bot className="w-7 h-7 text-[#ff2d53]" />
                </div>

                {/* Title */}
                <h3 className="text-xl font-semibold text-white mb-4">
                  The "Legion" | AI Operations Division
                </h3>

                {/* Description */}
                <p className="text-white/60 leading-relaxed mb-6">
                  Ace Guardian is supported by a proprietary legion of specialized Large Language 
                  Models (LLMs) and autonomous agents. These digital team members operate 24/7, 
                  handling everything from code optimization to threat simulation. This 
                  "Silicon Workforce" allows Ace Guardian to operate with the output and efficiency 
                  of a large-scale enterprise team, without the bureaucratic slowdowns.
                </p>

                {/* Stats */}
                <div className="flex gap-6">
                  <div>
                    <div className="text-2xl font-bold gradient-text">24/7</div>
                    <div className="text-xs text-white/50">Operations</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold gradient-text">AI</div>
                    <div className="text-xs text-white/50">Powered</div>
                  </div>
                  <div>
                    <div className="text-2xl font-bold gradient-text">∞</div>
                    <div className="text-xs text-white/50">Scalable</div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* AI Network Visualization */}
        <div className="mt-16 reveal">
          <div className="relative p-8 rounded-2xl bg-white/[0.05] backdrop-blur-sm border border-white/10 overflow-hidden">
            <div className="text-center mb-8">
              <h4 className="text-lg font-medium text-white mb-2">
                The Silicon Workforce
              </h4>
              <p className="text-sm text-white/50">
                Our AI agents work in concert to deliver unparalleled performance
              </p>
            </div>

            {/* Network Nodes */}
            <div className="relative h-48 flex items-center justify-center">
              {/* Central Node */}
              <div className="absolute w-16 h-16 rounded-full bg-gradient-to-br from-[#7f5cff] to-[#00e1ff] flex items-center justify-center z-10 animate-pulse">
                <span className="text-xl font-bold text-white">L</span>
              </div>

              {/* Orbiting Nodes */}
              {[0, 60, 120, 180, 240, 300].map((angle, index) => (
                <div
                  key={index}
                  className="absolute w-10 h-10 rounded-full bg-white/5 border border-white/20 flex items-center justify-center"
                  style={{
                    animation: `orbit 12s linear infinite`,
                    animationDelay: `${index * 2}s`,
                  }}
                >
                  <div
                    className="absolute"
                    style={{
                      transform: `rotate(${angle}deg) translateX(80px)`,
                    }}
                  >
                    <Bot className="w-4 h-4 text-white/40" />
                  </div>
                </div>
              ))}

              {/* Connection Lines */}
              <svg className="absolute inset-0 w-full h-full" style={{ opacity: 0.2 }}>
                <defs>
                  <linearGradient id="lineGradient" x1="0%" y1="0%" x2="100%" y2="100%">
                    <stop offset="0%" stopColor="#7f5cff" />
                    <stop offset="100%" stopColor="#00e1ff" />
                  </linearGradient>
                </defs>
                {[0, 60, 120, 180, 240, 300].map((angle, index) => (
                  <line
                    key={index}
                    x1="50%"
                    y1="50%"
                    x2={`${50 + 25 * Math.cos((angle * Math.PI) / 180)}%`}
                    y2={`${50 + 25 * Math.sin((angle * Math.PI) / 180)}%`}
                    stroke="url(#lineGradient)"
                    strokeWidth="1"
                    strokeDasharray="4 4"
                  />
                ))}
              </svg>
            </div>
          </div>
        </div>
      </div>

      <style>{`
        @keyframes orbit {
          from {
            transform: rotate(0deg);
          }
          to {
            transform: rotate(360deg);
          }
        }
      `}</style>
    </section>
  );
};

export default Team;
