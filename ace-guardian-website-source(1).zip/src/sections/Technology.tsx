import { RefreshCw, Zap, Cpu, Lock, Globe, Activity } from 'lucide-react';

const features = [
  {
    icon: RefreshCw,
    title: 'Self-Healing Architecture',
    description:
      'The Lalilama AI system is engineered with an autonomic core, enabling it to detect, diagnose, and repair anomalies within its own operational framework. This ensures unparalleled system resilience, continuous uptime, and proactive issue resolution.',
    stats: '99.99% Uptime | <50ms Recovery',
    color: '#7f5cff',
  },
  {
    icon: Zap,
    title: 'Rapid Response Capabilities',
    description:
      'Leveraging the lightweight Lalilama core, Ace Guardian AI Pro executes real-time threat analysis and decision-making at edge speeds. This architecture ensures instantaneous feedback, minimizing latency and providing immediate, actionable intelligence.',
    stats: '<10ms Response | Edge Computing',
    color: '#00e1ff',
  },
];

const techSpecs = [
  { icon: Cpu, label: 'Edge Computing', desc: 'Local processing' },
  { icon: Lock, label: 'Privacy First', desc: 'Data stays on device' },
  { icon: Globe, label: 'Universal Deploy', desc: 'Cross-platform' },
  { icon: Activity, label: 'Real-time Monitor', desc: '24/7 oversight' },
];

const Technology = () => {
  return (
    <section id="technology" className="relative py-24 md:py-32 bg-[#090909]">
      {/* Background Elements */}
      <div className="absolute inset-0">
        <div className="absolute top-1/2 left-0 w-[500px] h-[500px] rounded-full bg-[#7f5cff]/5 blur-[150px] -translate-y-1/2" />
        <div className="absolute top-1/2 right-0 w-[400px] h-[400px] rounded-full bg-[#00e1ff]/5 blur-[120px] -translate-y-1/2" />
      </div>

      <div className="relative z-10 max-w-[1440px] mx-auto px-[5%]">
        {/* Section Header */}
        <div className="text-center mb-20 reveal">
          <span className="inline-block px-4 py-1.5 rounded-full bg-white/5 border border-white/10 text-sm text-white/60 mb-6">
            Core Technology
          </span>
          <h2 className="text-3xl sm:text-4xl md:text-5xl font-semibold text-white mb-4">
            Powered by{' '}
            <span className="gradient-text">Lalilama AI</span>
          </h2>
          <p className="max-w-2xl mx-auto text-white/60 text-lg">
            The Engine Behind Enterprise-Grade Security
          </p>
        </div>

        {/* Feature Cards - Aligned Grid Layout */}
        <div className="grid grid-cols-1 lg:grid-cols-2 gap-8 lg:gap-12">
          {features.map((feature, index) => (
            <div
              key={index}
              className="group relative flex flex-col h-full rounded-3xl bg-white/[0.02] border border-white/10 overflow-hidden card-hover reveal"
            >
              {/* Card Content - Flex column for equal height */}
              <div className="flex flex-col h-full p-8">
                {/* Top Section: Icon + Title + Description */}
                <div className="flex-1">
                  {/* Icon */}
                  <div
                    className="w-14 h-14 rounded-xl flex items-center justify-center mb-6 transition-transform duration-300 group-hover:scale-110"
                    style={{ backgroundColor: `${feature.color}15` }}
                  >
                    <feature.icon
                      className="w-7 h-7"
                      style={{ color: feature.color }}
                    />
                  </div>

                  {/* Title */}
                  <h3 className="text-xl md:text-2xl font-semibold text-white mb-4">
                    {feature.title}
                  </h3>

                  {/* Description */}
                  <p className="text-white/60 leading-relaxed mb-6">
                    {feature.description}
                  </p>
                </div>

                {/* Bottom Section: Stats Badge + Visual */}
                <div>
                  {/* Stats Badge */}
                  <div
                    className="inline-flex items-center gap-2 px-4 py-2 rounded-full text-sm font-medium mb-6"
                    style={{
                      backgroundColor: `${feature.color}15`,
                      color: feature.color,
                    }}
                  >
                    {feature.stats}
                  </div>

                  {/* Visual Element */}
                  <div
                    className="relative aspect-[16/10] rounded-2xl overflow-hidden border border-white/10"
                    style={{
                      background: `linear-gradient(135deg, ${feature.color}08 0%, transparent 50%)`,
                    }}
                  >
                    {/* Animated Background */}
                    <div
                      className="absolute inset-0 opacity-50"
                      style={{
                        background: `radial-gradient(circle at 50% 50%, ${feature.color}20 0%, transparent 70%)`,
                      }}
                    />

                    {/* Center Icon */}
                    <div className="absolute inset-0 flex items-center justify-center">
                      <div
                        className="relative w-20 h-20 rounded-full border-2 flex items-center justify-center"
                        style={{ borderColor: `${feature.color}40` }}
                      >
                        <div
                          className="w-14 h-14 rounded-full border flex items-center justify-center"
                          style={{ borderColor: `${feature.color}60` }}
                        >
                          <feature.icon
                            className="w-6 h-6"
                            style={{ color: feature.color }}
                          />
                        </div>

                        {/* Orbiting Dot */}
                        <div
                          className="absolute w-2.5 h-2.5 rounded-full"
                          style={{
                            backgroundColor: feature.color,
                            animation: `orbit 8s linear infinite`,
                            transform: 'translateX(45px)',
                          }}
                        />
                      </div>
                    </div>

                    {/* Decorative Lines */}
                    <div className="absolute top-1/3 left-1/4 w-12 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                    <div className="absolute bottom-1/3 right-1/4 w-12 h-px bg-gradient-to-r from-transparent via-white/20 to-transparent" />
                  </div>
                </div>
              </div>

              {/* Accent Line */}
              <div
                className="absolute bottom-0 left-0 right-0 h-1 transform scale-x-0 group-hover:scale-x-100 transition-transform duration-500 origin-left"
                style={{
                  background: `linear-gradient(90deg, ${feature.color} 0%, transparent 100%)`,
                }}
              />
            </div>
          ))}
        </div>

        {/* Tech Specs Grid */}
        <div className="mt-20 reveal">
          <div className="grid grid-cols-2 md:grid-cols-4 gap-6">
            {techSpecs.map((spec, index) => (
              <div
                key={index}
                className="group p-6 rounded-2xl bg-white/[0.02] border border-white/10 hover:border-[#7f5cff]/30 transition-all duration-300 text-center"
              >
                <div className="w-12 h-12 rounded-xl bg-[#7f5cff]/10 flex items-center justify-center mx-auto mb-4 group-hover:scale-110 transition-transform duration-300">
                  <spec.icon className="w-6 h-6 text-[#7f5cff]" />
                </div>
                <div className="text-white font-medium mb-1">{spec.label}</div>
                <div className="text-sm text-white/50">{spec.desc}</div>
              </div>
            ))}
          </div>
        </div>
      </div>

      <style>{`
        @keyframes orbit {
          from {
            transform: rotate(0deg) translateX(45px) rotate(0deg);
          }
          to {
            transform: rotate(360deg) translateX(45px) rotate(-360deg);
          }
        }
      `}</style>
    </section>
  );
};

export default Technology;
